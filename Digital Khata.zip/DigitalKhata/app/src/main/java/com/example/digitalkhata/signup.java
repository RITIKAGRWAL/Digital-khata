package com.example.digitalkhata;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class signup extends AppCompatActivity {
    EditText uname,uemail,upass,ucpass,umobile,upostal;
    String u_name,u_email,u_pass,u_cpass,u_mobile,u_postal;
    Button btn;
    TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        getSupportActionBar().setTitle("sign up user");

        uname=(EditText)findViewById(R.id.name);
        uemail=findViewById(R.id.email);
        upass=findViewById(R.id.password);
        ucpass=findViewById(R.id.c_password);
        umobile=findViewById(R.id.mobile);
        upostal=findViewById(R.id.postal);
        btn=findViewById(R.id.create);
        tv=findViewById(R.id.tv);


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                u_name=uname.getText().toString();
                u_email=uemail.getText().toString();
                u_pass=upass.getText().toString();
                u_cpass=ucpass.getText().toString();
                u_mobile=umobile.getText().toString();
                u_postal=upostal.getText().toString();

                if ((TextUtils.isEmpty(u_name)||TextUtils.isEmpty(u_email) ||TextUtils.isEmpty(u_pass) ||TextUtils.isEmpty(u_cpass)||TextUtils.isEmpty(u_mobile)||TextUtils.isEmpty(u_postal)))
                {
                    Toast.makeText(signup.this, "All Fields Are mandatory", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    register();
                }
            }
        });
    }

    private void register() {
        FirebaseAuth auth= FirebaseAuth.getInstance();
        auth.createUserWithEmailAndPassword(u_email,u_pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()){
                    Toast.makeText(signup.this, "User Created", Toast.LENGTH_SHORT).show();
                    // Write a message to the database
                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                    DatabaseReference myRef = database.getReference("message");

                    myRef.setValue("Hello, World!");
                }
                else {
                    Toast.makeText(signup.this, "Not registered", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
