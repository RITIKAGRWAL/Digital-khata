package com.example.digitalkhata;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().setTitle("login user");
    }

    public  void click2(View V)
    {
        startActivity(new Intent(getApplicationContext(),signup.class));
    }
}
